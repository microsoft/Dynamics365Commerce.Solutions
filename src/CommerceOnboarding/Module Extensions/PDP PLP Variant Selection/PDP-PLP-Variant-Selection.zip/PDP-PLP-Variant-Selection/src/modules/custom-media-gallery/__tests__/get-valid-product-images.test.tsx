import * as RetailActions from '@msdyn365-commerce-modules/retail-actions';
import { buildHydratedMockActionContext } from '@msdyn365-commerce/core';
import { getValidProductImages } from '../utils';

interface IReturnObj {
    open(): void;
    send(): void;
}

describe('getValidProductImages', () => {
    // @ts-ignore
    function createMockXMLHttpRequest(): XMLHttpRequest {
        let urlParam: string = '';

        const returnObj = {
            open: jest.fn(),
            send: jest.fn()
        } as IReturnObj;

        const open = jest.fn().mockImplementation((method, url)  => {
            urlParam = url;
        });

        const send = jest.fn().mockImplementation(() => {
            if (urlParam === '200' || urlParam === '201' || urlParam === '404') {
                if (urlParam === '404') {
                    // @ts-ignore
                    returnObj.status = 404;
                }
                if (urlParam === '200') {
                    // @ts-ignore
                    returnObj.status = 200;
                }
                if (urlParam === '201') {
                    // @ts-ignore
                    returnObj.status = 201;
                }
                // @ts-ignore
                returnObj.onload();
            } else if (urlParam === 'throw') {
                throw new Error('fail');
            } else {
                // @ts-ignore
                returnObj.onerror();
            }
        });

        returnObj.open = open;
        returnObj.send = send;

        // @ts-ignore
        return returnObj;
    }

    it('Returns empty if getMediaLocationsForSelectedVariant returns empty', async () => {
        // @ts-ignore
        RetailActions.getMediaLocationsForSelectedVariant = jest.fn().mockResolvedValue(undefined);

        const result = await getValidProductImages(0, 0, buildHydratedMockActionContext());

        expect(result).toEqual([]);
    });

    it('Returns empty if getMediaLocationsForSelectedVariant throws', async () => {
        // @ts-ignore
        RetailActions.getMediaLocationsForSelectedVariant = jest.fn().mockRejectedValue('FAIL');

        const result = await getValidProductImages(0, 0, buildHydratedMockActionContext());

        expect(result).toEqual([]);
    });

    it('Filters returned results to make sure they actually exist', async () => {
        // @ts-ignore
        window.XMLHttpRequest = jest.fn(createMockXMLHttpRequest);

        // @ts-ignore
        RetailActions.getMediaLocationsForSelectedVariant = jest.fn().mockResolvedValue([
            { Uri: '201', AltText: 'Image 1' },
            { Uri: 'fail', AltText: 'Image 2' },
            { Uri: '200', AltText: 'Image 3' },
            { Uri: undefined, AltText: undefined },
            { Uri: 'throw', AltText: 'Image 5' },
            { Uri: '404', AltText: 'Image 6' }
        ]);

        const result = await getValidProductImages(0, 0, buildHydratedMockActionContext());

        expect(result.length).toEqual(2);
        expect(result).toEqual(expect.arrayContaining([
            expect.objectContaining({ src: '201', altText: 'Image 1'}),
            expect.objectContaining({ src: '200', altText: 'Image 3'})
        ]));
    });
});