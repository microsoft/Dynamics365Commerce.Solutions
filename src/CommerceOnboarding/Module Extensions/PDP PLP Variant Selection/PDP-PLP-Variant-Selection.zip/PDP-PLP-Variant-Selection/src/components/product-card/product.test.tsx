import { buildMockCoreContext, ICoreContext, IImageSettings } from '@msdyn365-commerce/core';
import { ProductSearchResult } from '@msdyn365-commerce/retail-proxy';
import { render } from 'enzyme';
import * as React from 'react';
import ProductComponent from './product.component';

const mockProduct: ProductSearchResult = {
    RecordId: 22565429819,
    ItemId: '81120',
    Name: 'Cotton Polo',
    Description: 'Casual shirts are made for the \u201cgood times\u201d.  Our custom fitting shirts are relaxed enough to be comfortable without looking baggy.',
    BasePrice: 59.99,
    Price: 59.99,
    TotalRatings: 182,
    AverageRating: 3.71428571428571,
    PrimaryImageUrl:'https://cms-ppe-imageresizer-mr.trafficmanager.net/cms/api/fabrikamsb/imageFileData/search?fileName=/Products%2F91032_000_001.png'
};

const mockProductWithoutImage: ProductSearchResult = {
    RecordId: 22565429819,
    ItemId: '81120',
    Name: 'Cotton Polo',
    Description: 'Casual shirts are made for the \u201cgood times\u201d.  Our custom fitting shirts are relaxed enough to be comfortable without looking baggy.',
    BasePrice: 59.99,
    Price: 59.99,
    TotalRatings: 182,
    AverageRating: 3.71428571428571
};

const mockProductWithoutName: ProductSearchResult = {
    RecordId: 22565429819,
    ItemId: '81120',
    Name: '',
    Description: 'Casual shirts are made for the \u201cgood times\u201d.  Our custom fitting shirts are relaxed enough to be comfortable without looking baggy.',
    BasePrice: 59.99,
    Price: 59.99,
    TotalRatings: 182,
    AverageRating: 3.71428571428571,
    PrimaryImageUrl:'https://cms-ppe-imageresizer-mr.trafficmanager.net/cms/api/fabrikamsb/imageFileData/search?fileName=/Products%2F91032_000_001.png'
};

const mockProductWithoutRating: ProductSearchResult = {
    RecordId: 22565429819,
    ItemId: '81120',
    Name: '',
    Description: 'Casual shirts are made for the \u201cgood times\u201d.  Our custom fitting shirts are relaxed enough to be comfortable without looking baggy.',
    BasePrice: 59.99,
    Price: 59.99,
    PrimaryImageUrl:'https://cms-ppe-imageresizer-mr.trafficmanager.net/cms/api/fabrikamsb/imageFileData/search?fileName=/Products%2F91032_000_001.png'
};

const defaultImageSettings: IImageSettings = {
    viewports: {
        xs: { q: 'w=315&h=315&m=6', w: 0, h: 0 },
        lg: { q: 'w=315&h=315&m=6', w: 0, h: 0 }
    },
    lazyload: true
};

describe('Product component renders correctly', () => {
    const mockCoreContext = buildMockCoreContext({app: {config: {hideRating: false}}}) as ICoreContext;

    it('renders product correctly', () => {
        const wrapper = render((
            <ProductComponent
             context={mockCoreContext}
             imageSettings={defaultImageSettings}
             id='test'
             typeName='test'
             data={{product: mockProduct}}
             imgConfig=''
             includeProductNavWithDimIdConfig={false}
            />
        ));
        expect(wrapper).toMatchSnapshot();
    });

    it('returns null for a null product', () => {
        const wrapper = render((
            <ProductComponent
             context={mockCoreContext}
             imageSettings={defaultImageSettings}
             id='test'
             typeName='test'
             data={{}}
             imgConfig=''
             includeProductNavWithDimIdConfig={false}
            />
        ));
        expect(wrapper.find('a')).toHaveLength(0);
    });

    it('Image is not displayed for invalid images', () => {
        const wrapper = render((
            <ProductComponent
             context={mockCoreContext}
             imageSettings={defaultImageSettings}
             id='test'
             typeName='test'
             data={{product: mockProductWithoutImage}}
             imgConfig=''
             includeProductNavWithDimIdConfig={false}
            />
        ));
        expect(wrapper).toMatchSnapshot();
    });

    it('Product without a name', () => {
        const wrapper = render((
            <ProductComponent
             context={mockCoreContext}
             imageSettings={defaultImageSettings}
             id='test'
             typeName='test'
             data={{product: mockProductWithoutName}}
             imgConfig=''
             includeProductNavWithDimIdConfig={false}
            />
        ));
        expect(wrapper).toMatchSnapshot();
    });

    it('Product without image alttext', () => {
        const wrapper = render((
            <ProductComponent
             context={mockCoreContext}
             imageSettings={defaultImageSettings}
             id='test'
             typeName='test'
             data={{product: mockProductWithoutName}}
             imgConfig=''
             includeProductNavWithDimIdConfig={false}
            />
        ));
        expect(wrapper).toMatchSnapshot();
    });

    it('Product without rating information', () => {
        const wrapper = render((
            <ProductComponent
             context={mockCoreContext}
             imageSettings={defaultImageSettings}
             id='test'
             typeName='test'
             data={{product: mockProductWithoutRating}}
             imgConfig=''
             includeProductNavWithDimIdConfig={false}
            />
        ));
        expect(wrapper).toMatchSnapshot();
    });
});