/*--------------------------------------------------------------
 * Copyright (c) Microsoft Corporation. All rights reserved.
 * See License.txt in the project root for license information.
 *--------------------------------------------------------------*/

/* eslint-disable no-duplicate-imports */
import { Module, Node } from '@msdyn365-commerce-modules/utilities';
import * as React from 'react';
import { IAddressSelectItem, IAddressSelectProps } from '../../common/components/address-select';
import { IAddressAddItem, IAddressAddUpdateProps } from '../../common/components/address-add';
import { IAddressShowItem, IAddressShowProps } from '../../common/components/address-show';
import { ICheckoutBillingAddressViewProps } from './custom-checkout-billing-address';

const AddressShow: React.FC<IAddressShowProps> = ({
    AddressDetail,
    items
}) => {

    return (
        <Node {...AddressDetail}>
            {items && items.map((item: IAddressShowItem) => {
                return (
                    <>
                        {item.description}
                    </>
                );
            })}
        </Node>
    );
};

const AddressSelect: React.FC<IAddressSelectProps> = ({
    SelectAddress,
    addButton,
    items,
    isShowSaveButton,
    saveButton,
    isShowCancelButton,
    cancelButton
}) => {

    return (
        <Node {...SelectAddress}>
            {addButton}
            {items && items.map((item: IAddressSelectItem) => {
                const SelectItem = item.SelectItem;
                return (<Node {...SelectItem} key={item.key}>
                    {item.input}
                    <AddressShow {...item.showItems} />
                </Node>);
            })}
            {isShowSaveButton && saveButton}
            {isShowCancelButton && cancelButton}
        </Node>
    );
};

const AddressAddUpdate: React.FC<IAddressAddUpdateProps> = ({
    AddressForm,
    heading,
    items,
    hasError,
    error,
    isShowSaveButton,
    saveButton,
    isShowCancelButton,
    cancelButton
}) => {

    return (
        <Node {...AddressForm}>
            {heading}
            {items && items.map((item: IAddressAddItem) => {
                const { AddressItem, key, label, alert, input } = item;
                return (<Node {...AddressItem} key={key}>
                    {label}
                    {alert}
                    {input}
                </Node>);
            })}
            {hasError && <Node {...error.AddressError}>
                {error.title}
                {error.message}
            </Node>}
            {isShowSaveButton && saveButton}
            {isShowCancelButton && cancelButton}
        </Node>
    );
};

const CheckoutBillingAddressView: React.FC<ICheckoutBillingAddressViewProps> = props => {
    const { CheckoutBillingAddress, showAddressSelect, viewState, heading, sameAsShippingCheckbox, showAddress, showAddOrUpdateAddress } = props;

    return (
        <Module {...CheckoutBillingAddress}>
            {heading}
            {viewState.isShowSameAsShippingCheckbox && sameAsShippingCheckbox}
            {viewState.isShowAddress && <AddressShow {...showAddress} />}
            {viewState.isShowAddresList && <AddressSelect {...showAddressSelect} />}
            {viewState.isShowAddOrUpdateAddress && <AddressAddUpdate {...showAddOrUpdateAddress} />}
        </Module>
    );
};

export default CheckoutBillingAddressView;
