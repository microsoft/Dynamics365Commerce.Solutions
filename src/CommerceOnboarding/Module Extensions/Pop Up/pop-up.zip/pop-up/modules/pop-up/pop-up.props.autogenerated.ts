/**
 * Copyright (c) 2018 Microsoft Corporation
 * IPopUp moduleDefinition Interface Properties
 * THIS FILE IS AUTO-GENERATED - MANUAL MODIFICATIONS WILL BE LOST
 */

import * as Msdyn365 from '@msdyn365-commerce/core';
import * as React from 'react';

export interface IPopUpConfig {
    heading?: string;
    className?: string;
    isBackDropStatic?: boolean;
    isCookieEnabled?: boolean;
    shouldPopUpOnLoad?: boolean;
}

export interface IPopUpResources {
    popUpAriaLabel: string;
}

export interface IPopUpProps<T> extends Msdyn365.IModule<T> {
    resources: IPopUpResources;
    config: IPopUpConfig;
    slots: {
        content: React.ReactNode[];
    };
}
